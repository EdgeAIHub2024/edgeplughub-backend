#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
人脸检测插件 - SDK兼容版本
按照EdgePlugHub SDK插件接口规范实现
"""

import os
import sys
import logging
from typing import Dict, Any, Optional

# 导入SDK插件基类
try:
    from edgeplughub_sdk.sdk.plugin_base import PluginBase, PluginInput, PluginOutput, DataType
except ImportError:
    # 如果无法导入SDK，创建模拟的类
    class PluginBase:
        def __init__(self):
            pass
            
    class PluginInput:
        def __init__(self, data_type=None, data=None, metadata=None):
            self.data_type = data_type
            self.data = data
            self.metadata = metadata
            
    class PluginOutput:
        def __init__(self, success=False, data=None, error_message=None, metadata=None):
            self.success = success
            self.data = data
            self.error_message = error_message
            self.metadata = metadata
            
    class DataType:
        TEXT = "text"
        IMAGE = "image"
        JSON = "json"
        VIDEO = "video"

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("face_detector.plugin")

class Plugin(PluginBase):
    """人脸检测插件类"""
    
    def __init__(self):
        """初始化插件"""
        super().__init__()
        
        # 设置插件元数据
        self.plugin_id = "ad4fe5c0-914f-4a1d-a8b6-7143e19085fc"
        self.name = "Face Detector"
        self.version = "1.0.0"
        self.description = "检测图像中的人脸并提供位置信息"
        self.category = "input"
        self.author = "FitVerse Team"
        
        # 设置支持的数据类型
        self.supported_input_types = [DataType.IMAGE, DataType.TEXT]
        self.supported_output_types = [DataType.JSON]
        
        # 设置默认配置
        self.config = {
            'min_face_size': 100,
            'show_landmarks': True,
            'save_result': True,
            'return_image': True,
            'draw_face': True
        }
        
        # 处理函数
        self.process_func = None
    
    def validate_input(self, input_data):
        """验证输入数据类型是否支持
        
        Args:
            input_data: 插件输入数据
            
        Returns:
            bool: 是否支持该输入类型
        """
        if hasattr(input_data, 'data_type'):
            return input_data.data_type in self.supported_input_types
        return False
    
    def initialize(self):
        """初始化插件，加载必要资源"""
        try:
            logger.info(f"初始化人脸检测插件 v{self.version}")
            
            # 检查依赖
            try:
                import numpy
                import PIL
                import cv2
                logger.info("所有必要依赖已安装")
            except ImportError as e:
                logger.error(f"依赖导入错误: {e}")
                # 尝试安装依赖
                try:
                    import subprocess
                    install_script = os.path.join(os.path.dirname(__file__), 'install_deps.py')
                    if os.path.exists(install_script):
                        subprocess.check_call([sys.executable, install_script])
                        logger.info("依赖安装成功")
                except Exception as install_error:
                    logger.error(f"依赖安装失败: {install_error}")
                    return False
            
            # 导入处理函数
            try:
                from .process import process
                self.process_func = process
                logger.info("成功导入处理函数")
            except ImportError:
                try:
                    from process import process
                    self.process_func = process
                    logger.info("从process.py导入处理函数")
                except ImportError as e:
                    logger.error(f"无法导入处理函数: {e}")
                    return False
            
            return True
        except Exception as e:
            logger.error(f"初始化失败: {e}")
            return False
    
    def process(self, input_data):
        """处理输入数据
        
        Args:
            input_data: 插件输入数据
            
        Returns:
            插件输出数据
        """
        # 验证输入数据
        if not self.validate_input(input_data):
            return PluginOutput(
                success=False, 
                data=None, 
                error_message="不支持的输入数据类型"
            )
        
        try:
            # 确保已初始化
            if self.process_func is None:
                if not self.initialize():
                    return PluginOutput(
                        success=False,
                        data=None,
                        error_message="插件初始化失败"
                    )
            
            # 提取图像路径或数据
            image_data = None
            if input_data.data_type == DataType.TEXT:
                # 假设输入是图像路径
                image_path = input_data.data
                if not os.path.exists(image_path):
                    return PluginOutput(
                        success=False,
                        data=None,
                        error_message=f"图像文件不存在: {image_path}"
                    )
                image_data = image_path
            elif input_data.data_type == DataType.IMAGE:
                # 输入是图像数据
                image_data = input_data.data
            
            # 获取元数据中的参数
            params = input_data.metadata.get('params', {}) if input_data.metadata else {}
            
            # 合并默认配置和传入参数
            config = {**self.config, **params}
            
            # 调用处理函数
            result = self.process_func(image_data, config)
            
            # 转换为标准输出格式
            if result.get('success', False):
                # 构建返回数据
                data = {
                    'face_count': len(result.get('faces', [])),
                    'faces': result.get('faces', []),
                }
                
                # 如果有带人脸框的结果图像，添加到结果中
                if 'result_image' in result:
                    data['result_image'] = result['result_image']
                
                # 如果有裁剪的人脸图像，添加到结果中
                if 'face_image' in result:
                    data['face_image'] = result['face_image']
                
                return PluginOutput(
                    success=True,
                    data=data,
                    metadata={
                        'plugin_id': self.plugin_id,
                        'plugin_version': self.version,
                        'detection_type': 'face'
                    }
                )
            else:
                return PluginOutput(
                    success=False,
                    data=None,
                    error_message=result.get('error', '人脸检测失败'),
                    metadata={
                        'plugin_id': self.plugin_id,
                        'plugin_version': self.version
                    }
                )
                
        except Exception as e:
            logger.error(f"处理过程中出错: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return PluginOutput(
                success=False,
                data=None,
                error_message=f"处理过程中出错: {str(e)}"
            ) 