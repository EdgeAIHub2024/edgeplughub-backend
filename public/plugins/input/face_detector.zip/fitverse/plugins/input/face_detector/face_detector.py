#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
人脸检测器模块
支持多种人脸检测方法，包括OpenCV和MediaPipe
"""

import os
import cv2
import numpy as np
from PIL import Image
import logging

# 配置日志
logger = logging.getLogger("face_detector")

class FaceDetector:
    """人脸检测器基类"""
    
    def __init__(self, config=None):
        """
        初始化人脸检测器
        
        Args:
            config: 配置参数字典
        """
        self.config = config or {}
        self.detector_type = self.config.get('detector_type', 'opencv')
        self.confidence_threshold = self.config.get('confidence_threshold', 0.5)
        self.max_faces = self.config.get('max_faces', 1)
        
        # 根据检测器类型初始化
        if self.detector_type == 'opencv':
            self._init_opencv_detector()
        elif self.detector_type == 'mediapipe':
            self._init_mediapipe_detector()
        else:
            # 默认使用OpenCV
            logger.warning(f"未知的检测器类型: {self.detector_type}，将使用OpenCV")
            self._init_opencv_detector()
            
    def _init_opencv_detector(self):
        """初始化OpenCV人脸检测器"""
        # 加载OpenCV人脸检测级联分类器
        model_path = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
        if not os.path.exists(model_path):
            # 如果找不到默认路径，尝试本地路径
            model_path = self.config.get('opencv_model_path', 'models/haarcascade_frontalface_default.xml')
            
        self.detector = cv2.CascadeClassifier(model_path)
        if self.detector.empty():
            error_msg = f"无法加载OpenCV人脸检测器模型: {model_path}"
            logger.error(error_msg)
            raise ValueError(error_msg)
        
        logger.info(f"已初始化OpenCV人脸检测器，模型路径: {model_path}")
            
    def _init_mediapipe_detector(self):
        """初始化MediaPipe人脸检测器"""
        try:
            import mediapipe as mp
            self.mp = mp
            self.detector = mp.solutions.face_detection.FaceDetection(
                model_selection=1,  # 全范围检测模型
                min_detection_confidence=self.confidence_threshold
            )
            logger.info("已初始化MediaPipe人脸检测器")
        except ImportError:
            logger.warning("MediaPipe未安装，将使用OpenCV检测器代替")
            self._init_opencv_detector()
            
    def detect(self, image):
        """
        检测图像中的人脸
        
        Args:
            image: PIL Image、numpy数组或图像文件路径
            
        Returns:
            dict: 包含检测结果的字典
                - success: 是否成功检测到人脸
                - faces: 检测到的人脸列表，每个人脸为(x, y, w, h)
                - face_image: 裁剪出最大人脸的图像 (PIL.Image)
                - error: 错误信息（如果有）
        """
        # 加载图像
        pil_image = self._load_image(image)
        if pil_image is None:
            logger.error("无法加载图像")
            return {
                'success': False,
                'error': "无法加载图像",
                'faces': [],
                'face_image': None
            }
            
        # 将PIL图像转换为OpenCV格式
        image_cv = cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)
        
        # 根据检测器类型进行检测
        if self.detector_type == 'opencv':
            faces, face_image, success = self._detect_opencv(pil_image, image_cv)
            return {
                'success': success,
                'faces': faces,
                'face_image': face_image,
                'error': None if success else "未检测到人脸"
            }
        elif self.detector_type == 'mediapipe':
            faces, face_image, success = self._detect_mediapipe(pil_image, image_cv)
            return {
                'success': success,
                'faces': faces,
                'face_image': face_image,
                'error': None if success else "未检测到人脸"
            }
        else:
            faces, face_image, success = self._detect_opencv(pil_image, image_cv)
            return {
                'success': success,
                'faces': faces,
                'face_image': face_image,
                'error': None if success else "未检测到人脸"
            }
            
    def _load_image(self, image):
        """
        加载图像
        
        Args:
            image: PIL Image、numpy数组或图像文件路径
            
        Returns:
            PIL.Image: 加载的图像
        """
        try:
            if isinstance(image, str):
                # 文件路径
                if os.path.exists(image):
                    return Image.open(image)
                else:
                    logger.error(f"图像文件不存在: {image}")
                    return None
            elif isinstance(image, Image.Image):
                # 已经是PIL图像
                return image
            elif isinstance(image, np.ndarray):
                # Numpy数组
                if image.ndim == 2:
                    # 灰度图
                    return Image.fromarray(image, 'L')
                elif image.ndim == 3:
                    # RGB或BGR图
                    if image.shape[2] == 3:
                        return Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
                    elif image.shape[2] == 4:
                        return Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGRA2RGBA))
            
            logger.error(f"不支持的图像类型: {type(image)}")
            return None
        except Exception as e:
            logger.error(f"加载图像失败: {str(e)}")
            return None
            
    def _detect_opencv(self, pil_image, cv_image):
        """
        使用OpenCV检测人脸
        
        Args:
            pil_image: PIL格式图像
            cv_image: OpenCV格式图像
            
        Returns:
            faces: 检测到的人脸列表，每个人脸为(x, y, w, h)
            face_image: 裁剪出最大人脸的图像 (PIL.Image)
            success: 是否成功检测到人脸
        """
        # 转换为灰度图
        gray = cv2.cvtColor(cv_image, cv2.COLOR_BGR2GRAY)
        
        # 检测人脸 - 优化参数
        faces = self.detector.detectMultiScale(
            gray,
            scaleFactor=1.05,  # 更小的缩放因子，提高检测精度
            minNeighbors=6,    # 增加邻居数量，减少误检
            minSize=(50, 50)   # 增加最小人脸尺寸
        )
        
        # 如果没有检测到人脸
        if len(faces) == 0:
            logger.info("未检测到人脸")
            return [], pil_image, False
            
        # 选择最大的人脸
        max_face = max(faces, key=lambda rect: rect[2] * rect[3])
        x, y, w, h = max_face
        
        # 扩大边界以包含更多皮肤区域，但不要太大
        margin = int(max(w, h) * 0.1)  # 减小边距系数，使边界框更紧贴人脸
        x_min = max(0, x - margin)
        y_min = max(0, y - margin)
        x_max = min(pil_image.width, x + w + margin)
        y_max = min(pil_image.height, y + h + margin)
        
        # 裁剪人脸区域
        face_image = pil_image.crop((x_min, y_min, x_max, y_max))
        
        logger.info(f"使用OpenCV检测到{len(faces)}个人脸")
        return faces, face_image, True
        
    def _detect_mediapipe(self, pil_image, cv_image):
        """
        使用MediaPipe检测人脸
        
        Args:
            pil_image: PIL格式图像
            cv_image: OpenCV格式图像
            
        Returns:
            faces: 检测到的人脸列表，每个人脸为(x, y, w, h)
            face_image: 裁剪出最大人脸的图像 (PIL.Image)
            success: 是否成功检测到人脸
        """
        # 转换为RGB格式
        rgb_image = cv2.cvtColor(cv_image, cv2.COLOR_BGR2RGB)
        
        # 检测人脸
        results = self.detector.process(rgb_image)
        
        # 如果没有检测到人脸
        if not results.detections:
            logger.info("未检测到人脸")
            return [], pil_image, False
            
        # 创建人脸列表
        faces = []
        
        # 获取图像尺寸
        height, width, _ = cv_image.shape
        
        # 解析检测结果
        for detection in results.detections:
            bbox = detection.location_data.relative_bounding_box
            
            # 计算绝对坐标
            x = int(bbox.xmin * width)
            y = int(bbox.ymin * height)
            w = int(bbox.width * width)
            h = int(bbox.height * height)
            
            faces.append((x, y, w, h))
            
        # 选择检测概率最高的人脸
        detection = results.detections[0]
        bbox = detection.location_data.relative_bounding_box
        
        # 计算绝对坐标，并加入边距
        x = int(bbox.xmin * width)
        y = int(bbox.ymin * height)
        w = int(bbox.width * width)
        h = int(bbox.height * height)
        
        # 扩大边界以包含更多皮肤区域，但采用更小的边距
        margin = int(max(w, h) * 0.1)  # 减小边距系数，使边界框更紧贴人脸
        x_min = max(0, x - margin)
        y_min = max(0, y - margin)
        x_max = min(width, x + w + margin)
        y_max = min(height, y + h + margin)
        
        # 裁剪人脸区域
        face_image = pil_image.crop((x_min, y_min, x_max, y_max))
        
        logger.info(f"使用MediaPipe检测到{len(results.detections)}个人脸")
        return faces, face_image, True
        

# 便捷函数，直接检测人脸
def detect_face(image, detector_type='mediapipe', confidence_threshold=0.5):
    """
    便捷函数，直接检测图像中的人脸
    
    Args:
        image: PIL Image、numpy数组或图像文件路径
        detector_type: 检测器类型，'opencv'或'mediapipe'
        confidence_threshold: 置信度阈值
        
    Returns:
        faces: 检测到的人脸列表
        face_image: 裁剪出的人脸图像
        success: 是否检测成功
    """
    config = {
        'detector_type': detector_type,
        'confidence_threshold': confidence_threshold
    }
    detector = FaceDetector(config)
    return detector.detect(image)

def process(image_path, params=None):
    """处理图像函数，作为与其他模块兼容的API

    Args:
        image_path: 图像文件路径
        params: 处理参数

    Returns:
        dict: 处理结果，包含检测到的人脸信息
    """
    # 设置日志
    import logging
    logger = logging.getLogger('face_detector.process')
    logger.info(f"通过face_detector.py处理图像: {image_path}")
    
    try:
        # 初始化检测器
        detector = FaceDetector(params)
        
        # 处理图像
        result = detector.detect(image_path)
        return result
    except Exception as e:
        import traceback
        logger.error(f"处理图像时出错: {e}")
        logger.error(traceback.format_exc())
        return {
            'success': False,
            'error': str(e)
        } 