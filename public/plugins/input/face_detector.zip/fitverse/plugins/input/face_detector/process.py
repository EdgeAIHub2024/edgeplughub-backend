#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
人脸检测器处理函数
供主程序和插件管理器调用
"""

import os
import sys
import logging
import traceback
from pathlib import Path
import cv2
import numpy as np
from PIL import Image

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('face_detector.process')

def process(image_path, params=None):
    """
    处理图像并检测人脸
    
    Args:
        image_path: 图像文件路径
        params: 处理参数
        
    Returns:
        dict: 包含检测结果的字典
            {
                'success': 是否成功检测到人脸,
                'faces': 检测到的人脸列表，每个人脸为(x, y, w, h)或dict,
                'face_image': 裁剪出的人脸图像,
                'error': 错误信息
            }
    """
    logger.info(f"通过process.py处理图像: {image_path}")
    
    # 默认参数
    params = params or {}
    
    try:
        # 处理PIL版本冲突
        try:
            from PIL import Image
            logger.info("成功导入PIL")
        except ImportError as e:
            if "Core version" in str(e):
                logger.warning(f"PIL版本冲突: {e}")
                # 尝试修复Pillow冲突
                try:
                    subprocess_fix_pillow()
                    from PIL import Image
                    logger.info("修复PIL版本冲突后成功导入")
                except Exception as fix_error:
                    logger.error(f"修复PIL失败: {fix_error}")
                    return {'success': False, 'error': f"PIL版本冲突: {e}", 'faces': [], 'face_image': None}
            else:
                logger.error(f"导入PIL失败: {e}")
                return {'success': False, 'error': f"导入PIL失败: {e}", 'faces': [], 'face_image': None}
                
        # 确保图像存在
        if not os.path.exists(image_path):
            logger.error(f"图像文件不存在: {image_path}")
            return {'success': False, 'error': f"图像文件不存在: {image_path}", 'faces': [], 'face_image': None}
        
        # 导入人脸检测器类
        try:
            # 尝试从当前目录导入
            from face_detector import FaceDetector
            logger.info("成功导入FaceDetector类")
        except ImportError:
            try:
                # 尝试从当前文件同级目录导入
                sys.path.append(os.path.dirname(__file__))
                from face_detector import FaceDetector
                logger.info("从当前目录导入FaceDetector类")
            except ImportError as e:
                logger.error(f"无法导入FaceDetector类: {e}")
                return {'success': False, 'error': f"无法导入FaceDetector类: {e}", 'faces': [], 'face_image': None}
        
        # 创建人脸检测器实例
        detector_type = params.get('detector_type', 'opencv')
        confidence_threshold = params.get('confidence_threshold', 0.5)
        
        detector = FaceDetector({
            'detector_type': detector_type,
            'confidence_threshold': confidence_threshold
        })
        logger.info(f"创建人脸检测器: 类型={detector_type}, 置信度阈值={confidence_threshold}")
        
        # 检测人脸
        result = detector.detect(image_path)
        
        # 确保结果是字典格式
        if isinstance(result, tuple):
            # 如果返回的是旧格式元组 (faces, face_image, success)
            faces, face_image, success = result
            result = {
                'success': success,
                'faces': faces,
                'face_image': face_image,
                'error': None if success else "未检测到人脸"
            }
            logger.info("将元组结果转换为字典格式")
        
        # 记录检测结果
        if result.get('success', False):
            face_count = len(result.get('faces', []))
            logger.info(f"成功检测到 {face_count} 个人脸")
            
            # 在原图上绘制人脸框
            if params.get('draw_face', True):  # 默认启用绘制人脸框
                try:
                    # 加载原始图像
                    if isinstance(image_path, str):
                        original_img = Image.open(image_path)
                    else:
                        original_img = image_path
                        
                    # 转为OpenCV格式以便绘制
                    cv_img = cv2.cvtColor(np.array(original_img), cv2.COLOR_RGB2BGR)
                    
                    # 绘制每个人脸框
                    faces = result.get('faces', [])
                    for face in faces:
                        if isinstance(face, np.ndarray) and len(face) >= 4:
                            x, y, w, h = face[:4]
                        elif isinstance(face, dict) and 'position' in face:
                            x, y, w, h = face['position']
                        else:
                            continue
                            
                        # 绘制矩形框
                        cv2.rectangle(cv_img, (x, y), (x+w, y+h), (0, 255, 0), 2)
                        
                    # 转回PIL格式
                    result_img = Image.fromarray(cv2.cvtColor(cv_img, cv2.COLOR_BGR2RGB))
                    
                    # 添加到结果中
                    result['result_image'] = result_img
                    
                    # 如果需要保存结果
                    if params.get('save_result', False):
                        result_dir = os.path.join(os.path.dirname(__file__), "results")
                        os.makedirs(result_dir, exist_ok=True)
                        result_path = os.path.join(result_dir, "detected_face_with_rect.jpg")
                        result_img.save(result_path)
                        logger.info(f"保存带人脸框的检测结果到: {result_path}")
                        
                except Exception as draw_error:
                    logger.error(f"绘制人脸框时出错: {draw_error}")
            
            # 同时保存裁剪的人脸图像
            if params.get('save_result', False):
                try:
                    face_image = result.get('face_image')
                    if face_image and hasattr(face_image, 'save'):
                        # 创建结果目录
                        result_dir = os.path.join(os.path.dirname(__file__), "results")
                        os.makedirs(result_dir, exist_ok=True)
                        
                        # 保存人脸图像
                        result_path = os.path.join(result_dir, "cropped_face.jpg")
                        face_image.save(result_path)
                        logger.info(f"保存裁剪的人脸图像到: {result_path}")
                except Exception as save_error:
                    logger.error(f"保存人脸图像时出错: {save_error}")
        else:
            logger.warning(f"未检测到人脸或检测失败: {result.get('error', '未知错误')}")
        
        return result
        
    except Exception as e:
        logger.error(f"人脸检测过程中出错: {e}")
        logger.error(traceback.format_exc())
        return {
            'success': False,
            'error': str(e),
            'faces': [],
            'face_image': None
        }

def subprocess_fix_pillow():
    """使用子进程修复Pillow版本冲突"""
    import subprocess
    
    logger.info("尝试修复Pillow版本冲突")
    
    # 卸载当前的Pillow
    subprocess.check_call([sys.executable, "-m", "pip", "uninstall", "-y", "pillow"])
    
    # 清理pip缓存
    subprocess.check_call([sys.executable, "-m", "pip", "cache", "purge"])
    
    # 安装兼容版本
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pillow==9.5.0"])
    
    logger.info("Pillow版本修复完成")
    
    # 重新启动当前进程以确保使用新版本
    if "__file__" in globals():
        logger.info("重新启动当前进程以应用新的Pillow版本")
        os.execv(sys.executable, [sys.executable] + sys.argv)

if __name__ == "__main__":
    # 简单的命令行测试接口
    if len(sys.argv) > 1:
        image_path = sys.argv[1]
        print(f"处理图像: {image_path}")
        result = process(image_path, {'save_result': True})
        print(f"处理结果: 成功={result['success']}, 检测到的人脸数量={len(result.get('faces', []))}")
    else:
        print("用法: python process.py <图像路径>") 