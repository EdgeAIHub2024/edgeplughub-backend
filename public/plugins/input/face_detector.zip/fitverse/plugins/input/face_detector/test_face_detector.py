#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
人脸检测器测试程序
用于测试人脸检测功能并输出人脸区域图像
"""

import os
import sys
import logging
from pathlib import Path

# 添加必要的路径
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('face_detector.test')

def test_face_detection(image_path, output_dir=None, detector_type='opencv'):
    """
    测试人脸检测功能
    
    Args:
        image_path: 图像文件路径
        output_dir: 输出目录，如果为None则使用默认目录
        detector_type: 检测器类型，'opencv'或'mediapipe'
    """
    try:
        from face_detector import FaceDetector
        
        # 创建默认输出目录
        if output_dir is None:
            output_dir = os.path.join(current_dir, "results")
        os.makedirs(output_dir, exist_ok=True)
        
        # 打印相关信息
        logger.info(f"测试人脸检测: 图像={image_path}, 检测器类型={detector_type}")
        
        # 创建人脸检测器，配置参数
        config = {
            'detector_type': detector_type,
            'confidence_threshold': 0.5,  # 置信度阈值
            'max_faces': 1  # 只检测一个人脸
        }
        detector = FaceDetector(config)
        
        # 检测人脸
        result = detector.detect(image_path)
        
        if result['success']:
            # 提取结果
            faces = result['faces']
            face_image = result['face_image']
            
            # 打印人脸信息
            logger.info(f"成功检测到 {len(faces)} 个人脸")
            for i, face in enumerate(faces):
                x, y, w, h = face
                logger.info(f"人脸 #{i+1}: 位置=({x}, {y}), 尺寸={w}x{h}")
            
            # 保存人脸图像
            face_output_path = os.path.join(output_dir, "face_region.jpg")
            face_image.save(face_output_path)
            logger.info(f"已保存人脸区域图像到: {face_output_path}")
            
            # 如果结果中包含带框的图像，也保存它
            if 'result_image' in result:
                rect_output_path = os.path.join(output_dir, "face_with_rect.jpg")
                result['result_image'].save(rect_output_path)
                logger.info(f"已保存带检测框的图像到: {rect_output_path}")
                
            return True, face_output_path
        else:
            logger.error(f"未检测到人脸: {result.get('error', '未知错误')}")
            return False, None
            
    except Exception as e:
        logger.error(f"测试过程中出错: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return False, None

def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("用法: python test_face_detector.py <图像路径> [opencv|mediapipe]")
        
        # 尝试使用默认测试图像
        test_data_dir = os.path.join(current_dir, "test_data")
        if os.path.exists(test_data_dir):
            # 查找第一个图像文件
            for file in os.listdir(test_data_dir):
                if file.lower().endswith(('.jpg', '.jpeg', '.png')):
                    image_path = os.path.join(test_data_dir, file)
                    print(f"使用默认测试图像: {image_path}")
                    break
            else:
                # 尝试从skin_analyzer的test_data查找
                skin_test_data = os.path.join(os.path.dirname(current_dir), "skin_analyzer", "test_data", "face_test.jpg")
                if os.path.exists(skin_test_data):
                    image_path = skin_test_data
                    print(f"使用skin_analyzer的测试图像: {image_path}")
                else:
                    print("找不到默认测试图像")
                    return
        else:
            print("找不到默认测试图像")
            return
    else:
        image_path = sys.argv[1]
        
    # 确定检测器类型
    detector_type = sys.argv[2] if len(sys.argv) > 2 else 'opencv'
    if detector_type not in ['opencv', 'mediapipe']:
        print(f"不支持的检测器类型: {detector_type}")
        detector_type = 'opencv'
        
    # 测试两种检测器
    success_opencv, output_path_opencv = test_face_detection(image_path, detector_type='opencv')
    
    try:
        import mediapipe
        success_mediapipe, output_path_mediapipe = test_face_detection(image_path, detector_type='mediapipe')
    except ImportError:
        print("MediaPipe未安装，跳过MediaPipe检测器测试")
        success_mediapipe, output_path_mediapipe = False, None
    
    # 打印总结
    print("\n测试结果总结:")
    print(f"OpenCV检测器: {'成功' if success_opencv else '失败'}")
    if success_opencv:
        print(f" - 输出图像: {output_path_opencv}")
        
    print(f"MediaPipe检测器: {'成功' if success_mediapipe else '失败'}")
    if success_mediapipe:
        print(f" - 输出图像: {output_path_mediapipe}")

if __name__ == "__main__":
    main() 