#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
人脸检测插件GUI测试程序
此程序用于单独测试人脸检测插件功能，不依赖主应用程序
通过GUI界面与插件交互
"""

import os
import sys
import logging
import traceback
import subprocess
from pathlib import Path
import numpy as np

# 添加必要的路径
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)  # 确保当前目录在路径中
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# 导入Plugin类
try:
    from plugin import Plugin
    PLUGIN_CLASS_AVAILABLE = True
except ImportError:
    PLUGIN_CLASS_AVAILABLE = False
    logging.error("无法导入Plugin类，请确保plugin.py文件存在且正确")
    sys.exit(1)

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('face_detector_gui_test.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('face_detector.gui_test')

def check_and_install_dependency(package_name, import_name=None):
    """检查并安装单个依赖
    
    Args:
        package_name: pip包名称
        import_name: 导入名称，如果不同于package_name
        
    Returns:
        bool: 安装是否成功
    """
    import_name = import_name or package_name.split('>=')[0].split('==')[0]
    
    try:
        __import__(import_name)
        logger.info(f"{import_name}已安装")
        return True
    except ImportError:
        logger.warning(f"{import_name}未安装，尝试安装{package_name}")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", package_name])
            logger.info(f"成功安装{package_name}")
            return True
        except Exception as e:
            logger.error(f"安装{package_name}失败: {e}")
            return False

def check_dependencies():
    """检查并安装所有必要的依赖
    
    Returns:
        bool: 所有依赖是否已安装
    """
    dependencies = [
        ("numpy>=1.19.0", "numpy"),
        ("opencv-python>=4.5.0", "cv2"),
        ("pillow>=8.0.0", "PIL"),
        ("PyQt5>=5.15.0", "PyQt5")
    ]
    
    all_installed = True
    for package, module in dependencies:
        if not check_and_install_dependency(package, module):
            all_installed = False
            
    if not all_installed:
        # 尝试使用install_deps.py
        install_script = os.path.join(current_dir, 'install_deps.py')
        if os.path.exists(install_script):
            logger.info("尝试使用install_deps.py安装依赖")
            try:
                subprocess.check_call([sys.executable, install_script])
                logger.info("install_deps.py执行成功")
                return True
            except Exception as e:
                logger.error(f"执行install_deps.py失败: {e}")
                return False
    
    return all_installed

# 导入PyQt5
try:
    from PyQt5.QtWidgets import (
        QApplication, QMainWindow, QVBoxLayout, QHBoxLayout, 
        QWidget, QLabel, QPushButton, QFileDialog, QTextEdit,
        QGroupBox, QGridLayout, QMessageBox, QProgressBar
    )
    from PyQt5.QtGui import QPixmap, QImage
    from PyQt5.QtCore import Qt, QTimer, QThread, pyqtSignal
    logger.info("成功导入PyQt5")
except ImportError as e:
    logger.error(f"导入PyQt5失败: {e}")
    sys.exit(1)

class FaceDetectorUI(QMainWindow):
    """人脸检测测试UI"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("人脸检测插件测试")
        self.resize(800, 600)
        self.image_path = None
        self.plugin_instance = None
        
        # 初始化Plugin实例
        self._init_plugin()
        self._init_ui()
        self._connect_signals()
        
        # 自动加载默认测试图像
        QTimer.singleShot(300, self.load_default_image)
    
    def _init_plugin(self):
        """初始化Plugin实例"""
        try:
            self.plugin_instance = Plugin()
            if self.plugin_instance.initialize():
                logger.info("成功初始化Plugin实例")
            else:
                logger.error("Plugin实例初始化失败")
                QMessageBox.critical(self, "错误", "Plugin实例初始化失败")
                sys.exit(1)
        except Exception as e:
            logger.error(f"创建Plugin实例失败: {e}")
            QMessageBox.critical(self, "错误", f"创建Plugin实例失败: {e}")
            sys.exit(1)
    
    def _init_ui(self):
        """初始化UI"""
        # 中心组件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 主布局
        main_layout = QVBoxLayout(central_widget)
        
        # 标题
        title = QLabel("人脸检测插件测试")
        title.setStyleSheet("font-size: 20pt; font-weight: bold;")
        title.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title)
        
        # 工具栏
        toolbar = QWidget()
        toolbar_layout = QHBoxLayout(toolbar)
        
        self.select_btn = QPushButton("选择图像")
        self.detect_btn = QPushButton("检测人脸")
        self.detect_btn.setEnabled(False)
        
        toolbar_layout.addWidget(self.select_btn)
        toolbar_layout.addWidget(self.detect_btn)
        
        main_layout.addWidget(toolbar)
        
        # 内容区
        content = QWidget()
        content_layout = QHBoxLayout(content)
        
        # 图像区域
        image_group = QGroupBox("原始图像")
        image_layout = QVBoxLayout(image_group)
        
        self.image_label = QLabel("未选择图像")
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setMinimumSize(300, 300)
        self.image_label.setStyleSheet("border: 1px solid #ccc;")
        
        image_layout.addWidget(self.image_label)
        
        # 结果区域
        result_group = QGroupBox("检测结果")
        result_layout = QVBoxLayout(result_group)
        
        # 结果图像布局（水平排列两张图）
        result_images_layout = QHBoxLayout()
        
        # 带标记的原始图像
        marked_image_container = QWidget()
        marked_image_layout = QVBoxLayout(marked_image_container)
        marked_image_title = QLabel("标记的原始图像")
        marked_image_title.setAlignment(Qt.AlignCenter)
        self.result_image = QLabel("检测结果将显示在这里")
        self.result_image.setAlignment(Qt.AlignCenter)
        self.result_image.setMinimumSize(250, 250)
        self.result_image.setStyleSheet("border: 1px solid #ccc;")
        marked_image_layout.addWidget(marked_image_title)
        marked_image_layout.addWidget(self.result_image)
        
        # 裁剪的人脸图像
        face_image_container = QWidget()
        face_image_layout = QVBoxLayout(face_image_container)
        face_image_title = QLabel("裁剪的人脸图像")
        face_image_title.setAlignment(Qt.AlignCenter)
        self.face_image = QLabel("裁剪人脸将显示在这里")
        self.face_image.setAlignment(Qt.AlignCenter)
        self.face_image.setMinimumSize(250, 250)
        self.face_image.setStyleSheet("border: 1px solid #ccc;")
        face_image_layout.addWidget(face_image_title)
        face_image_layout.addWidget(self.face_image)
        
        # 添加到结果图像布局
        result_images_layout.addWidget(marked_image_container, 1)
        result_images_layout.addWidget(face_image_container, 1)
        
        self.result_text = QTextEdit()
        self.result_text.setReadOnly(True)
        self.result_text.setPlaceholderText("检测结果信息将显示在这里")
        self.result_text.setMaximumHeight(150)
        
        result_layout.addLayout(result_images_layout)
        result_layout.addWidget(self.result_text)
        
        # 进度条
        self.progress_bar = QProgressBar()
        self.progress_bar.setTextVisible(True)
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setFormat("处理进度: %p%")
        self.progress_bar.hide()
        
        # 添加到内容布局
        content_layout.addWidget(image_group, 1)
        content_layout.addWidget(result_group, 2)
        
        # 添加到主布局
        main_layout.addWidget(content, 1)
        main_layout.addWidget(self.progress_bar)
    
    def _connect_signals(self):
        """连接信号和槽"""
        self.select_btn.clicked.connect(self.on_select_image)
        self.detect_btn.clicked.connect(self.on_detect_faces)
    
    def load_default_image(self):
        """加载默认测试图像"""
        # 获取脚本所在目录
        script_dir = os.path.dirname(os.path.abspath(__file__))
        
        # 默认测试图像路径
        default_image = os.path.join(script_dir, "test_data", "face_test.jpg")
        
        if os.path.exists(default_image):
            self.image_path = default_image
            self.statusBar().showMessage(f"已加载默认测试图像: {os.path.basename(default_image)}")
            
            # 显示图像
            pixmap = QPixmap(default_image)
            pixmap = pixmap.scaled(
                300, 300, Qt.KeepAspectRatio, Qt.SmoothTransformation
            )
            self.image_label.setPixmap(pixmap)
            
            # 允许检测
            self.detect_btn.setEnabled(True)
        else:
            logger.warning(f"默认测试图像不存在: {default_image}")
            
            # 尝试查找任何图像文件
            test_data_dir = os.path.join(script_dir, "test_data")
            if os.path.exists(test_data_dir):
                for file in os.listdir(test_data_dir):
                    if file.lower().endswith(('.jpg', '.jpeg', '.png')):
                        alt_image = os.path.join(test_data_dir, file)
                        logger.info(f"找到替代图像: {file}")
                        
                        self.image_path = alt_image
                        self.statusBar().showMessage(f"已加载替代测试图像: {file}")
                        
                        # 显示图像
                        pixmap = QPixmap(alt_image)
                        pixmap = pixmap.scaled(
                            300, 300, Qt.KeepAspectRatio, Qt.SmoothTransformation
                        )
                        self.image_label.setPixmap(pixmap)
                        
                        # 允许检测
                        self.detect_btn.setEnabled(True)
                        break
    
    def on_select_image(self):
        """选择图像按钮点击事件"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "选择图像", "", "图像文件 (*.jpg *.jpeg *.png)"
        )
        
        if file_path:
            self.image_path = file_path
            self.statusBar().showMessage(f"已加载图像: {os.path.basename(file_path)}")
            
            # 显示图像
            pixmap = QPixmap(file_path)
            pixmap = pixmap.scaled(
                300, 300, Qt.KeepAspectRatio, Qt.SmoothTransformation
            )
            self.image_label.setPixmap(pixmap)
            
            # 允许检测
            self.detect_btn.setEnabled(True)
            
            # 清除结果
            self.result_text.clear()
            self.result_image.clear()
            self.result_image.setText("检测结果将显示在这里")
    
    def on_detect_faces(self):
        """检测人脸按钮点击事件"""
        if not self.image_path:
            QMessageBox.warning(self, "警告", "请先选择图像")
            return
        
        # 显示进度条
        self.progress_bar.setValue(0)
        self.progress_bar.show()
        
        # 使用QTimer模拟进度
        self.progress_timer = QTimer()
        self.progress_timer.timeout.connect(self._update_progress)
        self.progress_timer.start(50)  # 每50毫秒更新一次
        
        # 启动处理线程
        self.processing_thread = ProcessingThread(self.image_path, self.plugin_instance)
        self.processing_thread.resultReady.connect(self._on_result_ready)
        self.processing_thread.error.connect(self._on_error)
        self.processing_thread.start()
    
    def _update_progress(self):
        """更新进度条"""
        current = self.progress_bar.value()
        if current < 95:  # 最大到95%，剩余5%留给最终处理
            self.progress_bar.setValue(current + 1)
    
    def _on_result_ready(self, result):
        """处理结果就绪"""
        # 停止进度条
        if hasattr(self, 'progress_timer'):
            self.progress_timer.stop()
        self.progress_bar.setValue(100)
        QTimer.singleShot(500, self.progress_bar.hide)
        
        # 显示结果
        data = result.get('data', {})
        
        # 构建结果文本
        face_count = data.get('face_count', 0)
        text = f"🎉 检测成功! 找到 {face_count} 个人脸\n\n"
        
        if face_count > 0:
            # 添加每个人脸的信息
            faces = data.get('faces', [])
            for i, face in enumerate(faces):
                # 处理不同格式的人脸数据
                if isinstance(face, np.ndarray):
                    # 如果是numpy数组，直接解包
                    if len(face) >= 4:
                        x, y, w, h = face[:4]
                        confidence = 1.0  # 默认置信度
                    else:
                        logger.warning(f"人脸数组格式异常: {face}")
                        x, y, w, h = 0, 0, 0, 0
                        confidence = 0
                else:
                    # 如果是字典，使用get方法
                    x, y, w, h = face.get('position', [0, 0, 0, 0])
                    confidence = face.get('confidence', 0)
                
                text += f"✅ 人脸 #{i+1}: 位置=({x},{y},{w},{h}), 置信度={confidence:.2f}\n"
        else:
            text += "❌ 未检测到人脸"
        
        # 显示结果文本
        self.result_text.setText(text)
        
        # 显示带标记的原始图像
        if 'result_image' in data:
            self._display_image(data['result_image'], self.result_image, 250)
        
        # 显示裁剪的人脸图像
        if 'face_image' in data:
            self._display_image(data['face_image'], self.face_image, 250)
    
    def _display_image(self, image_data, target_label, size=250):
        """将图像数据显示在指定的标签上"""
        if isinstance(image_data, str) and os.path.exists(image_data):
            # 结果是图像路径
            pixmap = QPixmap(image_data)
        elif hasattr(image_data, 'tobytes'):
            # 结果是PIL图像
            qimage = QImage(
                image_data.tobytes(),
                image_data.width,
                image_data.height,
                QImage.Format_RGB888
            )
            pixmap = QPixmap.fromImage(qimage)
        elif hasattr(image_data, 'shape') and len(image_data.shape) == 3:
            # 结果是numpy数组
            height, width, channel = image_data.shape
            qimage = QImage(
                image_data.data,
                width,
                height,
                width * channel,
                QImage.Format_RGB888
            )
            pixmap = QPixmap.fromImage(qimage)
        else:
            logger.warning(f"未知的图像格式: {type(image_data)}")
            return
        
        # 显示图像
        pixmap = pixmap.scaled(
            size, size, Qt.KeepAspectRatio, Qt.SmoothTransformation
        )
        target_label.setPixmap(pixmap)
    
    def _on_error(self, error_message):
        """处理错误"""
        # 停止进度条
        if hasattr(self, 'progress_timer'):
            self.progress_timer.stop()
        self.progress_bar.hide()
        
        # 显示错误
        QMessageBox.critical(self, "错误", f"检测失败: {error_message}")
        self.result_text.setText(f"❌ 检测失败: {error_message}")

# 处理线程类
class ProcessingThread(QThread):
    """图像处理线程"""
    resultReady = pyqtSignal(dict)
    error = pyqtSignal(str)
    
    def __init__(self, image_path, plugin_instance):
        super().__init__()
        self.image_path = image_path
        self.plugin_instance = plugin_instance
    
    def run(self):
        """运行线程"""
        try:
            # 设置处理参数
            params = {
                'save_result': True,
                'return_image': True,
                'draw_face': True  # 在原始图像上绘制人脸框
            }
            
            logger.info(f"使用Plugin处理图像: {self.image_path}")
            
            # 尝试使用SDK的类
            try:
                from edgeplughub_sdk.sdk.plugin_base import PluginInput, DataType
                
                # 创建输入数据
                input_data = PluginInput(
                    data_type=DataType.TEXT,
                    data=self.image_path,
                    metadata={'params': params}
                )
            except ImportError:
                # 创建模拟的输入数据
                class MockPluginInput:
                    def __init__(self, data_type, data, metadata=None):
                        self.data_type = data_type
                        self.data = data
                        self.metadata = metadata
                
                class MockDataType:
                    TEXT = "text"
                
                input_data = MockPluginInput(
                    data_type=MockDataType.TEXT,
                    data=self.image_path,
                    metadata={'params': params}
                )
            
            # 调用插件处理
            output = self.plugin_instance.process(input_data)
            
            # 处理输出
            if hasattr(output, 'success'):
                if output.success:
                    result = {
                        'success': True,
                        'data': output.data
                    }
                else:
                    result = {
                        'success': False,
                        'error': output.error_message
                    }
            else:
                # 假设输出是字典形式
                result = output
            
            logger.info(f"处理结果: {result}")
            
            if result.get('success', False):
                self.resultReady.emit(result)
            else:
                self.error.emit(result.get('error', '处理失败'))
                
        except Exception as e:
            logger.error(f"处理线程出错: {e}")
            logger.error(traceback.format_exc())
            self.error.emit(f"处理出错: {str(e)}")

if __name__ == "__main__":
    # 检查依赖
    if not check_dependencies():
        logger.error("依赖检查失败，无法启动应用程序")
        sys.exit(1)
    
    # 启动应用程序
    app = QApplication(sys.argv)
    window = FaceDetectorUI()
    window.show()
    sys.exit(app.exec_()) 