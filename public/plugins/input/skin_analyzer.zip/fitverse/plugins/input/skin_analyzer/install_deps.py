#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
肤色分析插件依赖安装脚本
处理安装过程中可能出现的各种问题
"""

import os
import sys
import subprocess
import logging
import tempfile
import importlib.util
import shutil
from pathlib import Path

# 设置环境变量禁用交互
os.environ['PLUGIN_NON_INTERACTIVE'] = '1'
os.environ['PLUGIN_MANAGER_LAUNCH'] = '1'
os.environ['MPLBACKEND'] = 'Agg'  # 禁用Matplotlib交互式后端
os.environ['PIP_NO_INPUT'] = '1'  # 禁用pip交互式提示

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('skin_analyzer.install')

def check_if_module_exists(module_name):
    """检查模块是否已安装
    
    Args:
        module_name: 模块名称
        
    Returns:
        bool: 是否存在
    """
    try:
        spec = importlib.util.find_spec(module_name)
        return spec is not None
    except (ImportError, AttributeError):
        return False

def run_command(cmd, check=True):
    """运行命令并返回结果
    
    Args:
        cmd: 命令列表
        check: 是否检查返回状态
        
    Returns:
        tuple: (returncode, stdout, stderr)
    """
    try:
        # 设置一个无需交互的环境
        env = os.environ.copy()
        env['PIP_NO_INPUT'] = '1'
        
        process = subprocess.run(cmd, capture_output=True, text=True, check=check, env=env)
        return process.returncode, process.stdout, process.stderr
    except subprocess.CalledProcessError as e:
        logger.error(f"命令执行失败: {e}")
        return e.returncode, e.stdout, e.stderr

def install_package(package):
    """安装单个包
    
    Args:
        package: 包名
        
    Returns:
        bool: 是否成功
    """
    logger.info(f"正在安装: {package}")
    try:
        # 添加--no-input选项以禁用交互
        returncode, stdout, stderr = run_command([sys.executable, "-m", "pip", "install", "--no-input", package], check=False)
        if returncode == 0:
            logger.info(f"成功安装: {package}")
            return True
        else:
            logger.error(f"安装 {package} 失败: {stderr}")
            return False
    except Exception as e:
        logger.error(f"安装 {package} 时出错: {e}")
        return False

def install_dependencies():
    """安装所有依赖"""
    logger.info("开始安装肤色分析插件依赖...")
    
    # 确保pip是最新的
    run_command([sys.executable, "-m", "pip", "install", "--upgrade", "pip"], check=False)
    logger.info("pip已升级到最新版本")
    
    # 基本依赖
    dependencies = [
        "numpy>=1.21.0",
        "opencv-python>=4.5.0",
        "scikit-image>=0.18.0",
        "matplotlib>=3.3.0",
        "pillow==9.5.0"  # 使用指定版本的Pillow
    ]
    
    # 安装基本依赖
    successful = 0
    total = len(dependencies)
    
    for package in dependencies:
        if install_package(package):
            successful += 1
    
    # 检查关键依赖是否已安装
    if check_if_module_exists("PIL"):
        try:
            import PIL
            logger.info(f"PIL已安装，版本: {PIL.__version__}")
        except Exception as e:
            logger.error(f"导入PIL时出错: {e}")
    
    if check_if_module_exists("skimage"):
        try:
            import skimage
            logger.info(f"skimage已安装，版本: {skimage.__version__}")
        except Exception as e:
            logger.error(f"导入skimage时出错: {e}")
    
    if successful < total:
        logger.warning(f"仅安装了 {successful}/{total} 个依赖")
        return False
    
    logger.info(f"成功安装了所有 {total} 个依赖")
    return True

if __name__ == "__main__":
    try:
        success = install_dependencies()
        sys.exit(0 if success else 1)
    except Exception as e:
        logger.error(f"依赖安装过程中出错: {e}")
        sys.exit(1) 