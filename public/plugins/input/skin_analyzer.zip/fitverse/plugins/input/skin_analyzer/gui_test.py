#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
肤色分析插件GUI测试程序
此程序用于单独测试肤色分析插件功能，不依赖主应用程序
通过GUI界面与插件交互
"""

import os
import sys
import logging
import traceback
import subprocess
from pathlib import Path

# 添加必要的路径
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)  # 确保当前目录在路径中
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# 添加SDK路径
sdk_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))), "edgeplughub-sdk")
sys.path.insert(0, sdk_path)

# 导入SDK类
from sdk.plugin_base import PluginBase, PluginInput, PluginOutput, DataType

# 导入Plugin类
try:
    from plugin import Plugin
    PLUGIN_CLASS_AVAILABLE = True
    logging.info("成功从plugin.py导入Plugin类")
except ImportError as e:
    PLUGIN_CLASS_AVAILABLE = False
    logging.error(f"无法导入Plugin类: {e}")
    sys.exit(1)

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('skin_analyzer_gui_test.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('skin_analyzer.gui_test')

def check_and_install_dependency(package_name, import_name=None):
    """检查并安装单个依赖
    
    Args:
        package_name: pip包名称
        import_name: 导入名称，如果不同于package_name
        
    Returns:
        bool: 安装是否成功
    """
    import_name = import_name or package_name.split('>=')[0].split('==')[0]
    
    try:
        __import__(import_name)
        logger.info(f"{import_name}已安装")
        return True
    except ImportError:
        logger.warning(f"{import_name}未安装，尝试安装{package_name}")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", package_name])
            logger.info(f"成功安装{package_name}")
            return True
        except Exception as e:
            logger.error(f"安装{package_name}失败: {e}")
            return False

def check_dependencies():
    """检查并安装所有必要的依赖
    
    Returns:
        bool: 所有依赖是否已安装
    """
    dependencies = [
        ("numpy>=1.19.0", "numpy"),
        ("opencv-python>=4.5.0", "cv2"),
        ("pillow>=8.0.0", "PIL"),
        ("scikit-image>=0.18.0", "skimage"),
        ("matplotlib>=3.3.0", "matplotlib"),
        ("networkx>=2.5", "networkx"),
        ("colormath==2.1.1", "colormath"),
        ("PyQt5>=5.15.0", "PyQt5")
    ]
    
    all_installed = True
    for package, module in dependencies:
        if not check_and_install_dependency(package, module):
            all_installed = False
            
    if not all_installed:
        # 尝试使用install_deps.py
        install_script = os.path.join(current_dir, 'install_deps.py')
        if os.path.exists(install_script):
            logger.info("尝试使用install_deps.py安装依赖")
            try:
                subprocess.check_call([sys.executable, install_script])
                logger.info("install_deps.py执行成功")
                return True
            except Exception as e:
                logger.error(f"执行install_deps.py失败: {e}")
                return False
    
    return all_installed

# 导入PyQt5
try:
    from PyQt5.QtWidgets import (
        QApplication, QMainWindow, QVBoxLayout, QHBoxLayout, 
        QWidget, QLabel, QPushButton, QFileDialog, QTextEdit,
        QGroupBox, QGridLayout, QMessageBox, QProgressBar, QDialog
    )
    from PyQt5.QtGui import QPixmap, QImage
    from PyQt5.QtCore import Qt, QTimer, QThread, pyqtSignal
    logger.info("成功导入PyQt5")
except ImportError as e:
    logger.error(f"导入PyQt5失败: {e}")
    sys.exit(1)

class SkinAnalyzerUI(QMainWindow):
    """肤色分析测试UI"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("肤色分析插件测试")
        self.resize(800, 600)
        self.image_path = None
        self.plugin_instance = None
        
        # 初始化Plugin实例
        self._init_plugin()
        self._init_ui()
        self._connect_signals()
        
        # 自动加载默认测试图像
        QTimer.singleShot(300, self.load_default_image)
    
    def _init_plugin(self):
        """初始化Plugin实例"""
        try:
            self.plugin_instance = Plugin()
            if self.plugin_instance.initialize():
                logger.info("成功初始化Plugin实例")
            else:
                logger.error("Plugin实例初始化失败")
                QMessageBox.critical(self, "错误", "Plugin实例初始化失败")
                sys.exit(1)
        except Exception as e:
            logger.error(f"创建Plugin实例失败: {e}")
            QMessageBox.critical(self, "错误", f"创建Plugin实例失败: {e}")
            sys.exit(1)
    
    def _init_ui(self):
        """初始化UI"""
        # 中心组件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 主布局
        main_layout = QVBoxLayout(central_widget)
        
        # 标题
        title = QLabel("肤色分析插件测试")
        title.setStyleSheet("font-size: 20pt; font-weight: bold;")
        title.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title)
        
        # 工具栏
        toolbar = QWidget()
        toolbar_layout = QHBoxLayout(toolbar)
        
        self.select_btn = QPushButton("选择图像")
        self.analyze_btn = QPushButton("分析肤色")
        self.analyze_btn.setEnabled(False)
        
        toolbar_layout.addWidget(self.select_btn)
        toolbar_layout.addWidget(self.analyze_btn)
        
        main_layout.addWidget(toolbar)
        
        # 内容区
        content = QWidget()
        content_layout = QHBoxLayout(content)
        
        # 图像区域
        image_group = QGroupBox("原始图像")
        image_layout = QVBoxLayout(image_group)
        
        self.image_label = QLabel("未选择图像")
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setMinimumSize(300, 300)
        self.image_label.setStyleSheet("border: 1px solid #ccc;")
        
        image_layout.addWidget(self.image_label)
        
        # 结果区域
        result_group = QGroupBox("分析结果")
        result_layout = QVBoxLayout(result_group)
        
        self.result_text = QTextEdit()
        self.result_text.setReadOnly(True)
        self.result_text.setPlaceholderText("分析结果将显示在这里")
        
        # 创建颜色样本区域
        self.color_sample_area = QWidget()
        self.color_sample_layout = QGridLayout(self.color_sample_area)
        
        result_layout.addWidget(self.result_text)
        result_layout.addWidget(self.color_sample_area)
        
        # 进度条
        self.progress_bar = QProgressBar()
        self.progress_bar.setTextVisible(True)
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setFormat("处理进度: %p%")
        self.progress_bar.hide()
        
        # 添加到内容布局
        content_layout.addWidget(image_group, 1)
        content_layout.addWidget(result_group, 1)
        
        # 添加到主布局
        main_layout.addWidget(content, 1)
        main_layout.addWidget(self.progress_bar)
    
    def _connect_signals(self):
        """连接信号和槽"""
        self.select_btn.clicked.connect(self.on_select_image)
        self.analyze_btn.clicked.connect(self.on_analyze_skin)
    
    def load_default_image(self):
        """加载默认测试图像"""
        # 获取脚本所在目录
        script_dir = os.path.dirname(os.path.abspath(__file__))
        
        # 默认测试图像路径
        default_image = os.path.join(script_dir, "test_data", "face_test.jpg")
        
        # 如果face_test.jpg不存在，尝试从face_detector的test_data目录中复制
        if not os.path.exists(default_image):
            face_detector_test_data = os.path.join(os.path.dirname(script_dir), "face_detector", "test_data", "face_test.jpg")
            if os.path.exists(face_detector_test_data):
                logger.info(f"从face_detector复制face_test.jpg")
                try:
                    import shutil
                    os.makedirs(os.path.join(script_dir, "test_data"), exist_ok=True)
                    shutil.copy2(face_detector_test_data, default_image)
                    logger.info(f"成功复制测试图像: {default_image}")
                except Exception as e:
                    logger.error(f"复制测试图像失败: {e}")
        
        if os.path.exists(default_image):
            self.image_path = default_image
            self.statusBar().showMessage(f"已加载默认测试图像: {os.path.basename(default_image)}")
            
            # 显示图像
            pixmap = QPixmap(default_image)
            pixmap = pixmap.scaled(
                300, 300, Qt.KeepAspectRatio, Qt.SmoothTransformation
            )
            self.image_label.setPixmap(pixmap)
            
            # 允许分析
            self.analyze_btn.setEnabled(True)
        else:
            logger.warning(f"默认测试图像不存在: {default_image}")
            
            # 尝试查找任何图像文件
            test_data_dir = os.path.join(script_dir, "test_data")
            if os.path.exists(test_data_dir):
                for file in os.listdir(test_data_dir):
                    if file.lower().endswith(('.jpg', '.jpeg', '.png')):
                        alt_image = os.path.join(test_data_dir, file)
                        logger.info(f"找到替代图像: {file}")
                        
                        self.image_path = alt_image
                        self.statusBar().showMessage(f"已加载替代测试图像: {file}")
                        
                        # 显示图像
                        pixmap = QPixmap(alt_image)
                        pixmap = pixmap.scaled(
                            300, 300, Qt.KeepAspectRatio, Qt.SmoothTransformation
                        )
                        self.image_label.setPixmap(pixmap)
                        
                        # 允许分析
                        self.analyze_btn.setEnabled(True)
                        break
    
    def on_select_image(self):
        """选择图像按钮点击事件"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "选择图像", "", "图像文件 (*.jpg *.jpeg *.png)"
        )
        
        if file_path:
            self.image_path = file_path
            self.statusBar().showMessage(f"已加载图像: {os.path.basename(file_path)}")
            
            # 显示图像
            pixmap = QPixmap(file_path)
            pixmap = pixmap.scaled(
                300, 300, Qt.KeepAspectRatio, Qt.SmoothTransformation
            )
            self.image_label.setPixmap(pixmap)
            
            # 允许分析
            self.analyze_btn.setEnabled(True)
            
            # 清除结果
            self.result_text.clear()
            self._clear_color_samples()
    
    def on_analyze_skin(self):
        """分析肤色按钮点击事件"""
        if not self.image_path:
            QMessageBox.warning(self, "警告", "请先选择图像")
            return
        
        # 显示进度条
        self.progress_bar.setValue(0)
        self.progress_bar.show()
        
        # 清除现有的结果
        self.result_text.clear()
        self._clear_color_samples()
        
        # 使用QTimer模拟进度
        self.progress_timer = QTimer()
        self.progress_timer.timeout.connect(self._update_progress)
        self.progress_timer.start(50)  # 每50毫秒更新一次
        
        # 启动处理线程
        self.processing_thread = ProcessingThread(self.image_path, self.plugin_instance)
        self.processing_thread.resultReady.connect(self._on_result_ready)
        self.processing_thread.error.connect(self._on_error)
        self.processing_thread.start()
    
    def _update_progress(self):
        """更新进度条"""
        current = self.progress_bar.value()
        if current < 95:  # 最大到95%，剩余5%留给最终处理
            self.progress_bar.setValue(current + 1)
    
    def _on_result_ready(self, result):
        """处理结果就绪"""
        # 停止进度条
        if hasattr(self, 'progress_timer'):
            self.progress_timer.stop()
        self.progress_bar.setValue(100)
        QTimer.singleShot(500, self.progress_bar.hide)
        
        # 显示结果
        data = result.get('data', {})
        
        # 构建结果文本
        text = "🎉 肤色分析成功!\n\n"
        text += f"✅ 肤色类型: {data.get('skin_category', '未知')}\n"
        text += f"✅ 色调: {data.get('undertone', '未知')}\n"
        text += f"✅ 亮度: {data.get('brightness', '未知')}\n"
        
        # 获取RGB值
        rgb_value = data.get('rgb_value', None)
        lab_value = data.get('lab_value', None)
        
        if rgb_value:
            r, g, b = rgb_value
            text += f"✅ RGB值: ({r}, {g}, {b})\n"
            
            # 直接显示肤色色块，而不是加载图片
            self._display_color_sample(r, g, b)
        elif 'color_samples' in data:
            # 如果有多个颜色样本，显示它们
            samples = data['color_samples']
            self._show_color_samples(samples)
            
            # 找出主要样本并显示
            if samples and len(samples) > 0:
                main_sample = samples[0]  # 通常第一个是主要的肤色样本
                r, g, b = main_sample.get('rgb', [0, 0, 0])
                self._display_color_sample(r, g, b)
                
        if lab_value:
            l, a, b_val = lab_value
            text += f"✅ LAB值: L={l:.2f}, a={a:.2f}, b={b_val:.2f}\n"
        
        # 添加人脸检测信息
        if data.get('face_detected', False):
            text += f"\n✅ 人脸检测: 成功检测到人脸\n"
            
            # 如果有人脸区域图像路径，显示图像
            face_region_path = data.get('face_region_path')
            if face_region_path and os.path.exists(face_region_path):
                text += f"✅ 人脸区域: {os.path.basename(face_region_path)}\n"
                
                # 显示人脸区域图像
                self._display_face_region(face_region_path)
        else:
            text += "\n❌ 人脸检测: 未检测到人脸，使用原始图像\n"
        
        # 添加详细信息
        if 'details' in data:
            text += "\n详细信息:\n"
            for key, value in data['details'].items():
                text += f"- {key}: {value}\n"
        
        # 显示结果
        self.result_text.setText(text)
    
    def _display_color_sample(self, r, g, b):
        """显示单个大型颜色样本"""
        # 创建一个新的QLabel来展示颜色样本
        if hasattr(self, 'main_color_sample'):
            try:
                if not self.main_color_sample.isVisible():
                    self.main_color_sample = None
                else:
                    self.main_color_sample.deleteLater()
            except RuntimeError:
                # 对象可能已被删除
                self.main_color_sample = None
        
        # 创建颜色框
        self.main_color_sample = QLabel()
        self.main_color_sample.setFixedSize(200, 200)
        self.main_color_sample.setStyleSheet(f"background-color: rgb({r},{g},{b}); border: 2px solid #333; border-radius: 5px;")
        
        # 创建颜色信息
        color_info = QLabel(f"<b>肤色RGB:</b> {r}, {g}, {b}")
        color_info.setAlignment(Qt.AlignCenter)
        color_info.setStyleSheet("font-size: 14px; margin-top: 5px;")
        
        # 创建颜色样本标题
        sample_title = QLabel("<b>分析得到的肤色:</b>")
        sample_title.setAlignment(Qt.AlignCenter)
        sample_title.setStyleSheet("font-size: 16px; margin-bottom: 5px;")
        
        # 创建布局并添加组件
        sample_layout = QVBoxLayout()
        sample_layout.addWidget(sample_title)
        sample_layout.addWidget(self.main_color_sample, 1, Qt.AlignCenter)
        sample_layout.addWidget(color_info)
        
        # 清除现有布局中的组件
        self._clear_color_samples()
        
        # 创建一个容器，然后设置布局
        container = QWidget()
        container.setLayout(sample_layout)
        
        # 将容器添加到现有布局
        self.color_sample_layout.addWidget(container)
    
    def _display_face_region(self, face_region_path):
        """显示人脸区域图像"""
        try:
            # 创建一个群组框来包含人脸区域图像
            face_group = QGroupBox("检测到的人脸区域")
            face_layout = QVBoxLayout(face_group)
            
            # 创建人脸图像标签
            face_label = QLabel()
            pixmap = QPixmap(face_region_path)
            pixmap = pixmap.scaled(200, 200, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            face_label.setPixmap(pixmap)
            face_label.setAlignment(Qt.AlignCenter)
            
            # 创建带框的人脸图像路径
            rect_image_path = os.path.join(os.path.dirname(face_region_path), "face_with_rect.jpg")
            
            # 添加一个按钮，可以查看带检测框的图像
            if os.path.exists(rect_image_path):
                view_rect_btn = QPushButton("查看带检测框的图像")
                
                def show_rect_image():
                    """显示带检测框的图像"""
                    rect_dialog = QDialog(self)
                    rect_dialog.setWindowTitle("人脸检测结果")
                    rect_dialog.resize(500, 400)
                    
                    dialog_layout = QVBoxLayout(rect_dialog)
                    
                    # 图像标签
                    rect_label = QLabel()
                    rect_pixmap = QPixmap(rect_image_path)
                    rect_pixmap = rect_pixmap.scaled(480, 380, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                    rect_label.setPixmap(rect_pixmap)
                    rect_label.setAlignment(Qt.AlignCenter)
                    
                    # 关闭按钮
                    close_btn = QPushButton("关闭")
                    close_btn.clicked.connect(rect_dialog.accept)
                    
                    dialog_layout.addWidget(rect_label)
                    dialog_layout.addWidget(close_btn)
                    
                    rect_dialog.exec_()
                
                view_rect_btn.clicked.connect(show_rect_image)
                face_layout.addWidget(view_rect_btn)
            
            # 添加到布局
            face_layout.addWidget(face_label)
            
            # 添加到结果区域
            # 先清除现有的结果图像
            for i in range(self.color_sample_layout.count()):
                item = self.color_sample_layout.itemAt(i)
                widget = item.widget()
                if isinstance(widget, QGroupBox) and widget.title() == "检测到的人脸区域":
                    widget.deleteLater()
                    break
            
            # 添加人脸区域图像到布局
            self.color_sample_layout.addWidget(face_group)
            
        except Exception as e:
            logger.error(f"显示人脸区域图像失败: {e}")
    
    def _on_error(self, error_message):
        """处理错误"""
        # 停止进度条
        if hasattr(self, 'progress_timer'):
            self.progress_timer.stop()
        self.progress_bar.hide()
        
        # 显示错误
        QMessageBox.critical(self, "错误", f"分析失败: {error_message}")
        self.result_text.setText(f"❌ 分析失败: {error_message}")
    
    def _clear_color_samples(self):
        """清除颜色样本"""
        while self.color_sample_layout.count():
            item = self.color_sample_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()
    
    def _show_color_samples(self, samples):
        """显示多个颜色样本"""
        self._clear_color_samples()
        
        # 添加标题
        title = QLabel("肤色样本")
        title.setStyleSheet("font-weight: bold;")
        self.color_sample_layout.addWidget(title, 0, 0, 1, 4)
        
        # 限制最大样本数
        max_samples = min(len(samples), 16)
        cols = 4
        
        for i in range(max_samples):
            sample = samples[i]
            r, g, b = sample.get('rgb', [0, 0, 0])
            
            # 创建颜色样本方块
            color_box = QLabel()
            color_box.setStyleSheet(f"background-color: rgb({r},{g},{b}); border: 1px solid #000;")
            color_box.setFixedSize(40, 40)
            
            # 创建颜色信息标签
            info = QLabel(f"RGB: {r},{g},{b}")
            info.setWordWrap(True)
            
            # 将样本添加到网格
            row = i // cols * 2
            col = i % cols
            self.color_sample_layout.addWidget(color_box, row + 1, col)
            self.color_sample_layout.addWidget(info, row + 2, col)

# 处理线程类
class ProcessingThread(QThread):
    """图像处理线程"""
    resultReady = pyqtSignal(dict)
    error = pyqtSignal(str)
    
    def __init__(self, image_path, plugin_instance):
        super().__init__()
        self.image_path = image_path
        self.plugin_instance = plugin_instance
    
    def run(self):
        """运行线程"""
        try:
            # 设置处理参数
            params = {
                'save_result': True,
                'auto_crop': True,
                'detailed_analysis': True,
                'skip_face_detection': False  # 在UI模式下，我们期望图像中包含人脸
            }
            
            logger.info(f"使用Plugin处理图像: {self.image_path}")
            
            # 创建输入数据
            input_data = PluginInput(
                data_type=DataType.TEXT,
                data=self.image_path,
                metadata={'params': params}
            )
            
            # 调用插件处理
            output = self.plugin_instance.process(input_data)
            
            # 处理输出
            if hasattr(output, 'success'):
                if output.success:
                    result = {
                        'success': True,
                        'data': output.data
                    }
                else:
                    result = {
                        'success': False,
                        'error': output.error_message
                    }
            else:
                # 假设输出是字典形式
                result = output
            
            logger.info(f"处理结果: {result}")
            
            if result.get('success', False):
                self.resultReady.emit(result)
            else:
                self.error.emit(result.get('error', '处理失败'))
                
        except Exception as e:
            logger.error(f"处理线程出错: {e}")
            logger.error(traceback.format_exc())
            self.error.emit(f"处理出错: {str(e)}")

if __name__ == "__main__":
    # 检查依赖
    if not check_dependencies():
        logger.error("依赖检查失败，无法启动应用程序")
        sys.exit(1)
    
    # 启动应用程序
    app = QApplication(sys.argv)
    window = SkinAnalyzerUI()
    window.show()
    sys.exit(app.exec_()) 