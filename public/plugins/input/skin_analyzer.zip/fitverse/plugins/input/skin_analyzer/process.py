#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
皮肤分析器处理函数
供主程序和插件管理器调用
"""

import os
import sys
import logging
import traceback
from pathlib import Path

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('skin_analyzer.process')

def process(image_path, params=None):
    """
    处理图像并分析肤色
    
    Args:
        image_path: 图像文件路径
        params: 处理参数
        
    Returns:
        dict: 包含分析结果的字典
    """
    logger.info(f"开始处理图像: {image_path}")
    
    # 默认参数
    params = params or {}
    skip_face_detection = params.get('skip_face_detection', False)
    
    try:
        # 处理PIL版本冲突
        try:
            from PIL import Image
            logger.info("成功导入PIL")
        except ImportError as e:
            if "Core version" in str(e):
                logger.warning(f"PIL版本冲突: {e}")
                # 尝试修复Pillow冲突
                try:
                    subprocess_fix_pillow()
                    from PIL import Image
                    logger.info("修复PIL版本冲突后成功导入")
                except Exception as fix_error:
                    logger.error(f"修复PIL失败: {fix_error}")
                    return {'success': False, 'error': f"PIL版本冲突: {e}"}
            else:
                logger.error(f"导入PIL失败: {e}")
                return {'success': False, 'error': f"导入PIL失败: {e}"}
                
        # 确保图像存在
        if not os.path.exists(image_path):
            logger.error(f"图像文件不存在: {image_path}")
            return {'success': False, 'error': f"图像文件不存在: {image_path}"}
        
        # 加载图像
        try:
            image = Image.open(image_path)
            logger.info(f"已加载图像，尺寸: {image.size}, 模式: {image.mode}")
        except Exception as e:
            logger.error(f"加载图像失败: {e}")
            return {'success': False, 'error': f"加载图像失败: {e}"}
        
        # 导入依赖模块
        try:
            import numpy as np
            from skimage import color
            import matplotlib.pyplot as plt
            logger.info("成功导入基本依赖模块")
            
            # 不再尝试导入colormath
            use_colormath = False
            
            logger.info("成功导入所有依赖模块")
        except ImportError as e:
            logger.error(f"导入依赖模块失败: {e}")
            
            # 尝试自动安装依赖
            try:
                logger.info("尝试自动安装缺失的依赖")
                install_deps_path = os.path.join(os.path.dirname(__file__), "install_deps.py")
                if os.path.exists(install_deps_path):
                    import subprocess
                    subprocess.check_call([sys.executable, install_deps_path])
                    logger.info("依赖安装完成，重新尝试导入")
                    
                    # 重新导入
                    import numpy as np
                    from skimage import color
                    import matplotlib.pyplot as plt
                    
                    use_colormath = False
                    logger.info("安装依赖后成功导入所有模块")
                else:
                    logger.error(f"找不到依赖安装脚本: {install_deps_path}")
                    return {'success': False, 'error': f"缺少依赖: {e}"}
            except Exception as install_error:
                logger.error(f"安装依赖失败: {install_error}")
                return {'success': False, 'error': f"安装依赖失败: {install_error}"}
        
        # 如果不跳过人脸检测
        face_detected = False
        face_region_path = None
        if not skip_face_detection:
            try:
                # 使用内置的face_region模块检测人脸
                try:
                    logger.info("尝试进行人脸检测")
                    from face_region import detect_face_region
                    
                    # 检测人脸
                    face_detect_params = {
                        'save_result': params.get('save_result', True),
                        'margin': 0.1  # 10%的边距
                    }
                    face_result = detect_face_region(image_path, face_detect_params)
                    
                    if face_result['success']:
                        # 成功检测到人脸
                        image = face_result['face_image']
                        face_detected = True
                        face_region_path = face_result.get('face_region_path')
                        logger.info("成功检测到人脸并使用裁剪后的人脸图像")
                        
                        # 如果有带框的图像，也保存
                        if 'result_image' in face_result:
                            result_dir = os.path.join(os.path.dirname(__file__), "results")
                            os.makedirs(result_dir, exist_ok=True)
                            rect_image_path = os.path.join(result_dir, "face_with_rect.jpg")
                            face_result['result_image'].save(rect_image_path)
                            logger.info(f"已保存带检测框的图像到: {rect_image_path}")
                    else:
                        logger.warning(f"人脸检测失败: {face_result.get('error', '未知错误')}")
                        logger.warning("将使用原始图像进行分析")
                        
                except ImportError as import_error:
                    logger.warning(f"导入face_region模块失败: {import_error}")
                    logger.warning("将使用原始图像继续分析")
            except Exception as face_error:
                logger.error(f"人脸检测过程中出错: {face_error}")
                logger.warning("将使用原始图像继续分析")
        
        # 将图像转换为numpy数组
        img_array = np.array(image)
        logger.info(f"图像数组形状: {img_array.shape}")
        
        # 确保图像是RGB格式
        if len(img_array.shape) == 2:
            # 灰度图转RGB
            logger.info("将灰度图转换为RGB")
            img_array = np.stack((img_array,) * 3, axis=-1)
        elif img_array.shape[2] == 4:
            # RGBA转RGB
            logger.info("将RGBA图像转换为RGB")
            img_array = img_array[:, :, :3]
        
        # 计算平均颜色
        avg_color = np.mean(img_array, axis=(0, 1))
        r, g, b = avg_color.astype(int)
        
        logger.info(f"平均RGB颜色: ({r}, {g}, {b})")
        
        # 将RGB颜色转换为Lab颜色空间
        try:
            # 创建单像素RGB图像
            rgb_pixel = np.array([[[r/255, g/255, b/255]]], dtype=np.float64)
            # 转换为Lab
            lab_pixel = color.rgb2lab(rgb_pixel)
            L, a, b_val = lab_pixel[0, 0]
            logger.info(f"使用skimage转换，Lab颜色: L={L:.2f}, a={a:.2f}, b={b_val:.2f}")
        except Exception as skimage_error:
            logger.error(f"skimage转换失败: {skimage_error}")
            # 使用估算值
            L = 0.2126 * r + 0.7152 * g + 0.0722 * b
            a = (r - g) / 2
            b_val = (g - b) / 2
            logger.warning(f"使用估算计算Lab值: L={L:.2f}, a={a:.2f}, b={b_val:.2f}")
        
        # 分析肤色类型
        # L: 亮度 (0-100)
        # a: 红绿轴 (正值为红，负值为绿)
        # b: 黄蓝轴 (正值为黄，负值为蓝)
        
        # 基于Lab值确定肤色类型
        if L > 65:
            skin_category = "浅色"
        elif 55 <= L <= 65:
            skin_category = "中等"
        else:
            skin_category = "深色"
            
        # 基于a和b的值确定肤色倾向
        if a > 15 and b > 15:
            undertone = "暖色调"
        elif a < 10 and b < 10:
            undertone = "冷色调"
        else:
            undertone = "中性调"
            
        # 基于L值确定亮度
        if L > 70:
            brightness = "高"
        elif 50 <= L <= 70:
            brightness = "中"
        else:
            brightness = "低"
            
        # 保存分析结果图像（如果需要）
        if params.get('save_result', True):
            try:
                # 创建结果目录
                result_dir = os.path.join(os.path.dirname(__file__), "results")
                os.makedirs(result_dir, exist_ok=True)
                
                # 不再创建颜色样本图像，只记录RGB值
                logger.info(f"肤色RGB值: ({r}, {g}, {b})")
                
                # 直接在结果中包含RGB值（这部分已经在ret中包含了）
                # ret['data']['rgb_value'] = [r, g, b]
                
            except Exception as save_error:
                logger.error(f"保存结果时出错: {save_error}")
        
        # 返回结果
        ret = {
            'success': True,
            'data': {
                'skin_category': skin_category,
                'undertone': undertone,
                'brightness': brightness,
                'lab_value': [L, a, b_val],
                'rgb_value': [r, g, b],
                'details': {}
            }
        }
        
        # 添加人脸检测结果
        if face_detected:
            ret['data']['face_detected'] = True
            if face_region_path and os.path.exists(face_region_path):
                ret['data']['face_region_path'] = face_region_path
        else:
            ret['data']['face_detected'] = False
        
        # 如果有color_distance变量存在，添加到结果中
        try:
            if 'color_distance' in locals():
                ret['data']['details']['color_distance'] = color_distance
        except:
            pass
            
        # 如果有temperature变量存在，添加到结果中
        try:
            if 'temperature' in locals():
                ret['data']['details']['temperature'] = temperature
        except:
            pass
            
        # 如果有颜色样本，添加到结果中
        if 'color_samples' in locals() and color_samples:
            ret['data']['color_samples'] = color_samples
        
        logger.info(f"分析结果: 肤色类型={skin_category}, 色调={undertone}, 亮度={brightness}")
        return ret
        
    except Exception as e:
        logger.error(f"皮肤分析过程中出错: {e}")
        logger.error(traceback.format_exc())
        return {
            'success': False,
            'error': str(e)
        }

def subprocess_fix_pillow():
    """使用子进程修复Pillow版本冲突"""
    import subprocess
    
    logger.info("尝试修复Pillow版本冲突")
    
    # 卸载当前的Pillow
    subprocess.check_call([sys.executable, "-m", "pip", "uninstall", "-y", "pillow"])
    
    # 清理pip缓存
    subprocess.check_call([sys.executable, "-m", "pip", "cache", "purge"])
    
    # 安装兼容版本
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pillow==9.5.0"])
    
    logger.info("Pillow版本修复完成")
    
    # 重新启动当前进程以确保使用新版本
    if "__file__" in globals():
        logger.info("重新启动当前进程以应用新的Pillow版本")
        os.execv(sys.executable, [sys.executable] + sys.argv)

if __name__ == "__main__":
    # 简单的命令行测试接口
    if len(sys.argv) > 1:
        image_path = sys.argv[1]
        print(f"处理图像: {image_path}")
        result = process(image_path, {'save_result': True})
        print(result)
    else:
        print("用法: python process.py <图像路径>") 