#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
简单的人脸区域检测模块
直接使用OpenCV实现，不依赖于face_detector插件
"""

import os
import sys
import cv2
import numpy as np
import logging
from PIL import Image

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('skin_analyzer.face_region')

def detect_face_region(image_path, params=None):
    """
    检测图像中的人脸区域
    
    Args:
        image_path: 图像文件路径或PIL图像对象
        params: 处理参数
            - save_result: 是否保存结果图像
            - margin: 人脸边界扩展比例，默认0.1
            
    Returns:
        dict: 包含检测结果的字典
            {
                'success': 是否成功检测到人脸,
                'face_image': 裁剪出的人脸图像,
                'face_region_path': 保存的人脸区域图像路径,
                'error': 错误信息
            }
    """
    params = params or {}
    margin = params.get('margin', 0.1)  # 默认边距为10%
    save_result = params.get('save_result', True)
    
    try:
        # 加载图像
        if isinstance(image_path, str):
            if not os.path.exists(image_path):
                logger.error(f"图像文件不存在: {image_path}")
                return {'success': False, 'error': f"图像文件不存在: {image_path}"}
            
            pil_image = Image.open(image_path)
            cv_image = cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)
        elif isinstance(image_path, Image.Image):
            pil_image = image_path
            cv_image = cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)
        else:
            logger.error(f"不支持的图像类型: {type(image_path)}")
            return {'success': False, 'error': f"不支持的图像类型: {type(image_path)}"}
        
        # 加载OpenCV人脸检测器
        cascade_path = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
        if not os.path.exists(cascade_path):
            logger.error(f"找不到人脸检测模型: {cascade_path}")
            return {'success': False, 'error': f"找不到人脸检测模型: {cascade_path}"}
        
        face_cascade = cv2.CascadeClassifier(cascade_path)
        
        # 转换为灰度图
        gray = cv2.cvtColor(cv_image, cv2.COLOR_BGR2GRAY)
        
        # 检测人脸 - 使用优化参数
        faces = face_cascade.detectMultiScale(
            gray,
            scaleFactor=1.05,  # 更小的缩放因子，提高检测精度
            minNeighbors=6,    # 增加邻居数量，减少误检
            minSize=(50, 50)   # 增加最小人脸尺寸
        )
        
        # 如果没有检测到人脸
        if len(faces) == 0:
            logger.warning("未检测到人脸，将使用原始图像")
            return {
                'success': False, 
                'error': '未检测到人脸',
                'face_image': pil_image
            }
        
        # 选择最大的人脸
        max_face = max(faces, key=lambda rect: rect[2] * rect[3])
        x, y, w, h = max_face
        
        # 扩大边界以包含更多皮肤区域
        face_margin = int(max(w, h) * margin)
        x_min = max(0, x - face_margin)
        y_min = max(0, y - face_margin)
        x_max = min(pil_image.width, x + w + face_margin)
        y_max = min(pil_image.height, y + h + face_margin)
        
        # 裁剪人脸区域
        face_image = pil_image.crop((x_min, y_min, x_max, y_max))
        
        # 在原始图像上绘制矩形框
        cv2.rectangle(cv_image, (x, y), (x + w, y + h), (0, 255, 0), 2)
        # 扩展边界
        cv2.rectangle(cv_image, (x_min, y_min), (x_max, y_max), (0, 0, 255), 2)
        
        # 转回PIL图像
        result_image = Image.fromarray(cv2.cvtColor(cv_image, cv2.COLOR_BGR2RGB))
        
        # 保存结果
        face_region_path = None
        if save_result:
            try:
                # 创建结果目录
                result_dir = os.path.join(os.path.dirname(__file__), "results")
                os.makedirs(result_dir, exist_ok=True)
                
                # 保存人脸区域图像
                face_region_path = os.path.join(result_dir, "face_region.jpg")
                face_image.save(face_region_path)
                logger.info(f"已保存人脸区域图像到: {face_region_path}")
                
                # 保存带框的图像
                rect_image_path = os.path.join(result_dir, "face_with_rect.jpg")
                result_image.save(rect_image_path)
                logger.info(f"已保存带检测框的图像到: {rect_image_path}")
                
            except Exception as save_error:
                logger.error(f"保存结果图像时出错: {save_error}")
        
        logger.info(f"成功检测到人脸，位置=({x}, {y}), 尺寸={w}x{h}")
        return {
            'success': True,
            'face_image': face_image,
            'face_region_path': face_region_path,
            'result_image': result_image,
            'face_rect': (x, y, w, h),
            'face_region': (x_min, y_min, x_max, y_max)
        }
        
    except Exception as e:
        import traceback
        logger.error(f"人脸区域检测出错: {e}")
        logger.error(traceback.format_exc())
        return {
            'success': False,
            'error': str(e),
            'face_image': None
        }

if __name__ == "__main__":
    # 简单的命令行测试接口
    if len(sys.argv) > 1:
        image_path = sys.argv[1]
        print(f"处理图像: {image_path}")
        
        result = detect_face_region(image_path, {'save_result': True})
        
        if result['success']:
            print(f"人脸检测成功: {result['face_region_path']}")
        else:
            print(f"人脸检测失败: {result.get('error', '未知错误')}")
    else:
        print("用法: python face_region.py <图像路径>") 